export default function App() {
const skills=["HTML","CSS","JavaScript","React","Node.js","MongoDB","Flutter"];
const projects=[
{title:"Student Management System",description:"CRUD application using Node.js and MongoDB"},
{title:"Weather App",description:"Live weather application using API integration"},
{title:"Portfolio Website",description:"Responsive personal portfolio"}
];
return (
<div style={{fontFamily:'Arial',padding:'20px',background:'#f1f5f9'}}>
<h1>Harishmitha</h1>
<p>B.Tech Student | Web Developer | Flutter Enthusiast</p>
<h2>About Me</h2>
<p>Passionate B.Tech student interested in software development and building real-world projects.</p>
<h2>Skills</h2>
<ul>{skills.map(s=><li key={s}>{s}</li>)}</ul>
<h2>Projects</h2>
{projects.map(p=><div key={p.title}><h3>{p.title}</h3><p>{p.description}</p></div>)}
</div>
)}
